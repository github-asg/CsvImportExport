import java.lang.*;
import java.io.IOException;

public class Test
{
public static void main(String[] ops) throws IOException
{
try
{
  CsvUnitTest csv = new CsvUnitTest();
  csv.test();
}
catch(Exception e)
{
}
}
}